Steps to  train the model.

1.run the given .py file 
2.result of prediction will be saved to submission.csv file 
3.get the result and verify with "Y_test " columns
